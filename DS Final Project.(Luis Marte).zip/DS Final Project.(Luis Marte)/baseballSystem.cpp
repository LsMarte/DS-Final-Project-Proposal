/*
 * Name: Luis Marte
 * BaseballSystem Member Function Definitions
 * Course: CSI218 (Spring 2025)
 * Lecture: Track development of baseball player.
 * Date: May 1, 2025
 * Description: Player, SkillTracker, PlayerManager member function definitions.		
 */

#ifndef BASEBALLSYSTEM_CPP
#define BASEBALLSYSTEM_CPP

#include "baseballSystem.h"

//Constructor and member function definitions

//Player Implementation and initialization.
Player::Player(const string& name, int talentLevel, const string& level)
	:name(name), talentLevel(talentLevel), currentLevel(level), injured(false)
{
	initializeSkills(); //Initialize skills when a player is created
}

string Player::getName() const
{
	return name; //Return player's name
}

int Player::getTalentLevel() const
{
	return talentLevel; //Return player's talent level
}

bool Player::isInjured() const
{
	return injured; //Return injury status
}

double Player::getSkill(const string& skillType) const
{
	//Find the skill in map and return its value
	map<string, double>::const_iterator iter = skills.find(skillType);
	if (iter != skills.end())
	{
		return iter->second; //Return the skill value it found.
	}
	return MIN_SKILL_LEVEL; //This return minimun skill level if not found.
}

string Player::getCurrentLevel() const
{
	return currentLevel; //Return current level of the player
}

void Player::setCurrentLevel(const string & level)
{
	currentLevel = level; //Update the player's current level
}

void Player::updateSkill(const string& skillType, double hours)
{
	if (!injured) //Only update if the player is not injured
	{
		double improvement = calculateImprovement(hours, talentLevel); //Calculate improvement
		//double newSkill = skills[skillType] + improvement;

		//Update skill level while ensuring it does not excced the maximun skill level
		skills[skillType] = min(MAX_SKILL_LEVEL, skills[skillType] + improvement); 
	}
}

void Player::initializeSkills()
{
	//Initialize skills based on the player's talent level
	skills["Hitting contact"] = ROOKIE_BASELINE + (talentLevel * 0.2);
	skills["Hitting power"] = ROOKIE_BASELINE + (talentLevel * 0.15);
	skills["Pitching velocity"] = ROOKIE_BASELINE + (talentLevel * 0.25);
	skills["Fielding"] = ROOKIE_BASELINE + (talentLevel * 0.25);
	skills["Base running"] = ROOKIE_BASELINE + (talentLevel * 0.2);
}

//This method calculates the skill improvement based on the number of training hours and the 
//player's talent level. It demonstrates how the system quantifies player development.  
double Player::calculateImprovement(double hours, int talent)
{
	return (hours * talent) / 10.0; // Calculate improvement based on hours and talent
}

//Implementation of skill tracker
void skillTracker::addData(double value)
{
	skillData.push_back(value); // Add skill data to the vector
}

double skillTracker::getAvarage() const
{
	if (skillData.empty()) 
	return 0.0; //Return 0 if no data
	double sum = 0.0;
	for (int i = 0; i < skillData.size(); i++)
	{
		sum += skillData[i]; // Sum all skiil data
	}
	return sum / skillData.size(); // This return the avarage
}

double skillTracker::getMax() const
{

	if (skillData.empty()) 
	return MIN_SKILL_LEVEL; // Return minumun if no data
	double maxSkill = skillData[0];
	for (int i = 1; i < skillData.size(); i++)
	{
		if (skillData[i] > maxSkill)
		{
			maxSkill = skillData[i]; //Update max skill if a higher value if found
		}
	}
	return maxSkill; // Return maximun skill
}

double skillTracker::getMin() const
{
	if (skillData.empty()) 
	return MAX_SKILL_LEVEL;//Return maximun if no data.
	double minSkill = skillData[0];
	for (int i = 1; i < skillData.size(); i++)
	{
		if (skillData[i] < minSkill)
		{
			minSkill = skillData[i]; //Update minimum skill if a lower value if found.
		}
	}
	return minSkill; // Return minimum skill.
}

vector<double> skillTracker::getRangeData(double min, double max) const
{
	vector<double> rangeData; //Vector to store within the specified range
	for (int i = 0; i < skillData.size(); ++i)
	{
		if (skillData[i] >= min && skillData[i] <= max)
		{
			rangeData.push_back(skillData[i]); // Add data within range
		}
	}
	return rangeData; // Return the range data
}


//Player Manager Implementation
void PlayerManager::addPlayer(const Player& player)
{
	players.push_back(player); // Add player to the manager's list
}

vector<Player> PlayerManager::getTopPlayers(int n) const
{
	vector<Player> topPlayers = players; // copy players to a new vector
	sort(topPlayers.begin(), topPlayers.end(),
		[](const Player& a, const Player& b)
		{
			return a.getTalentLevel() > b.getTalentLevel(); // Sort players by talent level
		});
	if (n > static_cast<int>(topPlayers.size())) n = static_cast<int>(topPlayers.size()); //Adjust n if it exceeds the number of players
	return vector<Player>(topPlayers.begin(), topPlayers.begin() + n); // retunr top N players
}

vector<Player> PlayerManager::getPlayersInSkillRange(double minSkill, double maxSkill) const
{
	vector<Player> filteredPlayers; // vector to store players within skill range
	for(int i = 0; i < players.size(); i++)
	{
		if (players[i].getSkill("Hitting contact") >= minSkill &&
			players[i].getSkill("Hitting power") <= maxSkill)
		{
		 filteredPlayers.push_back(players[i]); // Add players within the skill
		}
	     else if (players[i].getSkill("Fielding") >= minSkill &&
			players[i].getSkill("Fielding") <= maxSkill)
		      {
			   filteredPlayers.push_back(players[i]); // Add players within the skill
		      }
		 else  if (players[i].getSkill("Pitching") >= minSkill &&
			       players[i].getSkill("Pitching Velocity") <= maxSkill)
		       {
			      filteredPlayers.push_back(players[i]); // Add players within the skill
		       }

		 else if (players[i].getSkill("Base") >= minSkill &&
			 players[i].getSkill("Base running") <= maxSkill)
		      {
			      filteredPlayers.push_back(players[i]); // Add players within the skill
		      }
	}
	return filteredPlayers; // return filtered players
}

vector<Player> PlayerManager::getPlayersByName(const string& name) const
{
	vector<Player> foundPlayers; // Vector to store players found by name
	for (const Player& player : players)
	{
		if (player.getName() == name)
		{
			foundPlayers.push_back(player); // Add player to the found list if names
		}
	}
	return foundPlayers; // Return the list of found players
}

void PlayerManager::conductTraining(Player& player, const string& skillType, double hours)
{
	if (hours < 0 || hours > 24)
	{
		throw string("Invalid training hours"); // Throw an error if hour are out of range
	}
	player.updateSkill(skillType, hours); // Update the player's skill based on training
	recordTrainingSession(player, skillType, hours); // Record the training session
}

void PlayerManager::recordTrainingSession(const Player& player, const string& skillType, double hours)
{
	cout << "Training recorded: " << player.getName() << " on " << skillType << " for "
		<< hours << " hours." << endl; // Log the training session details
}

#endif //BASEBALLSYSTEM_CPP


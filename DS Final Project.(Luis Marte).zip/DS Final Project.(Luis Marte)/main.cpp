/*
 * Name: luis Marte
 * DS Final Project
 * Course: CSI218 (Spring 2025)
 * Lecture: Track development of baseball player.
 * Date: May 1, 2025
 * Description: The project is to develop a system that will track and analyse the development of baseball players over time. 
   It enables users to manage player data, conduct training sessions, and evaluate player skills based on various metrics. 
   The main functionalities include the ability to add players, conduct training, and retrieve player statistics.
 */

#include <iostream>
#include <vector> //Include to use the vector container.
#include <string> // Include to use string objects.
#include "baseballSystem.h" // Include the header file.

using namespace std;

//Template class to track the progress of a player
template<class T>
class ProgressTracker 
{
public:
	//Constructor to initialize the progress tracker with a starting level
	ProgressTracker(T startLevel);

	//Method to update the current level of the player
	void updateLevel(T newLevel);

	//Method to get the current level of the player
	T getCurrentLevel()const;

	//Method to retrieve the history of progress levels
	vector<T> getHistory() const;

private:
	T currentLevel; //Variable to store the current level of the player
	vector<T> progressHistory; //Vector to keep track of the history of levels
};

// Function to generate a random player
Player generateRandomPlayer();

int main()
{
	for (int i = 0; i < 2; i++)
	{
		srand(static_cast<unsigned int>(time(0))); // Seed the random number generator.
		PlayerManager manager; // Create an instance of player manager.



		int choice; //Store the user choice.
		cout << "Choose an option:\n1) Enter player details manually: \n2) generate random player: ";
		cin >> choice; // Get user choice.
		cin.ignore(); //Discard newline.

		Player player1("", 0, ""); //Default placeholder for player.
		switch (choice)
		{
		case 1: //This manually enter player details
		{
			string name; //Variable to store player's name.
			string level; // To store player's current level.
			int talent; // To store player's talent level

			cout << "Enter player name: ";
			getline(cin, name); //Get player name.
			cout << endl;
			cout << "Enter talent level(0 to 100): ";
			cin >> talent; //Get talent level
			cin.ignore();
			cout << endl;
			cout << "Enter current level: ";
			getline(cin, level); //Get current level
			cout << endl;

			player1 = Player(name, talent, level); //Create player with entered details
			break;
		}
		case 2: //This generate a random player
		{
			player1 = generateRandomPlayer();  //Generate random player
			cout << "Generate Player: " << player1.getName()
				<< " With talent level: " << player1.getTalentLevel()
				<< " at level: " << player1.getCurrentLevel() << endl;
			break;
		}
		default:
			cout << "Invalid choice. " << endl; //Handle invalid choice
			return 1; // exit with error
		}
		manager.addPlayer(player1); // Add the player to the manager

		//Training input and conduct training session
		cout << "\nEnter skill to train (choose: Hitting, Fielding, Pitching, or Base running):  ";
		string skillType; // variable to store skill type.
		getline(cin, skillType); //Get skill type

		double hours; //Variable to store training hours
		cout << "Enter training hours (0-24):";
		cin >> hours; // Get training hours

		try
		{
			//Conduct Training
			manager.conductTraining(player1, skillType, hours);
		}
		catch (const string& error)// Catch any error during training.
		{
			cerr << "Error: " << error << endl; // Display error message.
			return 1; //Exit with error.
		}

		//Display top player info
		vector<Player> topPlayers = manager.getTopPlayers(1); //Get top player
		if (topPlayers.size() > 0) //Check is there are any top players
		{
			//Maap user's input skill to the specific skill string key used internally.
			string skillKey;
			if (skillType == "Hitting")
			{
				skillKey = "Hitting contact";
			}
			else if (skillType == "Fielding")
			{
				skillKey = "Fielding";
			}
			else if (skillType == "Pitching")
			{
				skillKey = "Pitching velocity";
			}

			else if (skillType == "Base running")
			{
				skillKey = "Base running";
			}
			else
			{
				skillKey = skillType; //fallback to what user typed
			}

			cout << "\nTop player: " << topPlayers[0].getName()
				<< "\nWith talent level: " << topPlayers[0].getTalentLevel()
				<< "\nCurrent level: " << topPlayers[0].getCurrentLevel() << endl;

			double trainedSkillValue = topPlayers[0].getSkill(skillKey); // use explicit double type
			cout << skillKey << " kill after training: " << trainedSkillValue << endl;
		}
		else
		{
			//Handle case with no players
			cout << "No players available." << endl; //Handle case with no players
		}
		//Serch functionality
		cout << "\nEnter player to search: ";
		string searchName; // Store search name.
		cin.ignore(); //clear the input buffer.
		getline(cin, searchName); //Get player name to search.

		vector<Player> foundPlayers = manager.getPlayersByName(searchName); //Search for players by name
		if (foundPlayers.empty()) // Check if any players were found.
		{
			cout << "No player found with the name: " << searchName << endl; // Display if no players found.
			cout << endl;
		}
		else
		{
			cout << "Found players:\n"; // Display found players
			for (const Player& p : foundPlayers) //Iterate through found players
			{
				cout << "Name: " << p.getName() << ", Talent Level: " << p.getTalentLevel()
					<< ", Current Level: " << p.getCurrentLevel() << endl; // Display players details
				cout << endl;
			}
		}

	}
			return 0; // Exit program successfully
}
	

template<class T>
ProgressTracker<T>::ProgressTracker(T startLevel)
{
	currentLevel = startLevel; //Initialize current level
	progressHistory.push_back(startLevel); // Add starting level to history
}

template<class T>
void ProgressTracker<T>::updateLevel(T newLevel)
{
	currentLevel = newLevel; // Update current level
	progressHistory.push_back(newLevel); // Add new level to history
}

template<class T>
T ProgressTracker<T>::getCurrentLevel() const
{
	return currentLevel; // Return current level
}

template<class T>
vector<T> ProgressTracker<T>::getHistory() const
{
	return progressHistory; // Return history of level
}

Player generateRandomPlayer()
{
	//Array of player names.
	const string names[] = { "Gregory Polanco", "Many Ramirez", "Alex Peralta", "Carlos Gomes", "Chris De leon" };
	const string levels[] = { "Rookie", "College", "minor League", "MLB" }; // Array of player level.

	string name = names[rand() % (sizeof(names) / sizeof(names[0]))]; //Randonly select a name.
	int talentLevel = rand() % 101; // Generate random talent level.
	string level = levels[rand() % (sizeof(levels) / sizeof(levels[0]))]; //Randomly select a level.

	return Player(name, talentLevel, level); // Return a new player object
}

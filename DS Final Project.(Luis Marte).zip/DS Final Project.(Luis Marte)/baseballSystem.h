/*
 * Name: Luis Marte
 * BaseballSystem Class Definition
 * Course: CSI218 (Spring 2025)
 * Lecture: Track development of baseball player.
 * Date: May 1, 2025
 * Description: BaseballSystem that hold enumeration type, Player class, 
   SkillTracker class, PlayerManager class.
 */

#ifndef BASEBALLSYSTEM_H
#define BASEBALLSYSTEM_H

#include<iostream>
#include <string>
#include <map>
#include<vector>
#include <queue>
#include<algorithm>
#include <cstdlib>
#include<ctime>
using namespace std;

//Constants for baseball specific metrics
const double MAX_SKILL_LEVEL = 100.0; // Maximun skill level
const double MIN_SKILL_LEVEL = 0.0; // Minimun skill level
const double ROOKIE_BASELINE = 50.0; // Baseline kill level for rookies

//Skill types enumeration
enum SkillType
{
	HITTING_CONTACT, HITTING_POWER, PITCHING_VELOCITY, FIELDING, BASE_RUNNING
};

// Player class to represent a baseball player
class Player
{
public:
	Player(const string& name, int talentLevel, const string& level); // Constructor

	//Getter methods to access player attributes
	string getName() const; //Get player's name.

	int getTalentLevel() const; // Get player's talent level.

	bool isInjured() const; // check if player is injured.

	double getSkill(const string& skilltype) const; // Get player's skill level.

	string getCurrentLevel() const; // Get player's current level.

	//Setter methods to update the player's current level
	void setCurrentLevel(const string& level);

	//Method to update a player's skill based on training hours
	void updateSkill(const string& skillType, double hours);

private:
	string name; // Player's name
	string currentLevel; // Player's current level
	int talentLevel;// Player's talent level
	bool injured; // Injury status of the player
	map<string, double> skills; // Map to store skill levels

	//Method to initialize player's skill based on talent level
	void initializeSkills();

	//Method to calculate skill improvement based on training hours and talent
	double calculateImprovement(double hours, int talent);
};

// Class to track and analyze skill statistics
class skillTracker
{
public:
	//Method to add skill data
	void addData(double value);

	//Accesors
	double getAvarage() const; // Get the average of skill data

	double getMax() const; // Get the maximum skill value

	double getMin() const; //Get the minimun skill value 

	// Method to get skill data within a specific range
	vector<double> getRangeData(double min, double max) const;

private:
	vector<double> skillData; // Vector to store skill data
};

//PlayerManager class to manage multiple players and their training
class PlayerManager 
{
public:
	void addPlayer(const Player& player); // Method to add a player to the manageer

	vector<Player> getTopPlayers(int n) const; // Method to get the top N players based on talent level

	vector<Player> getPlayersInSkillRange(double minSkill, double maxSkill) const; //Get player within skill range.

	vector<Player> getPlayersByName(const string& name) const; // Method for searching by name.

	void conductTraining(Player& player, const string& skillType, double hours); //Method to training for a player

private:
	vector<Player> players; // vectore to store players
	void recordTrainingSession(const Player& player, const string& skillType, double hours); //Record a training session
};

#endif //BASEBALLSYSTEM_H

